
# coding: utf-8

# In[3]:


# -*- coding: utf-8 -*-
"""
Created on Sat Mar  2 13:39:31 2019

@author: KARTHEEK SUNKARA
"""

#The dataset is analyzed in ways that establish  a link between suicides_no and other attributes
#Ultimately trying to find the factors that are believed to have affected suicides_no

#1) Reads in data from a file 
#importing pandas to read master.csv file as df 
import pandas as pd
df = pd.read_csv(r'C:\Users\KARTHEEK SP\Desktop\Python\master.csv')

#listing the column labels/attributes 
list(df.columns.values)

"""Out:['country',
           'year',
           'sex',
           'age',
           'suicides_no',
           'population',
           'suicides/100k pop',
           'country-year',
           'HDI for year',
           ' gdp_for_year ($) ',
           'gdp_per_capita ($)',
           'generation']"""


#Shape of the dataframe
df.shape #Out:(27820,12)
#Looking at the first 5 entries
df.head(n=5)

#2) Cleans and formats the data 
#Data Cleaning and shaping

#Coulmn H in the dataset is a combination of country and year.
#Deleting the whole column
del df['country-year']

#Now checking the shape of the dataframe
df.shape #Out:(27820,11)

#Every pandas DataFrame has an immutable ndarray implementing an ordered, sliceable set. The basic object storing axis labels for all pandas objects. This works as an index for the table.
df.index #Out: RangeIndex(start=0, stop=27820, step=1)

#describe shows  a quick statistic summary of your data, on the numeric columns.
des=df.describe()
des

#Pandas assigns missing values with a numpy.NaN value, we can use this information to remove the rows or columns with missing data, or replace the missing values to another of out choosing.
#The argument how=’any’ is the default and will drop any row(or column) with any missing data.
df=df.dropna(how='any')

#Re indexing the rows from 0 to length of dataframe
df.index = pd.RangeIndex(len(df.index))

#We are now analyzing data to extract the insights abaout finding the factors believed to be affecting the suicides in different countries

a=[]
for i in df['country']:
    if i not in a:
        a.append(i)
        
#Now a is a list of all the countries whose data is available
print(a) #Out: 90
#Analyzing given data of 90 countries        


# In[5]:


# METHOD 1 OF ANALYSIS

# OVERALL ANALYSIS 
#initiating m and j dictionaries which are later used to capture suicides_no and 
#sum of gdp per capita per year of world respectively
m={}
j={}

#Iterating over the rows, checking if the year in row is present as a key in m
#If so, adding gdp_per_capita to the value of that particular key (which is year)
#if not, creating a key value pair with that year value of that particular row as key
for index, row in df.iterrows():
    if row[1] in j:
        j[row[1]]=j[row[1]]+row[9]
    elif row[1] not in j:
        j[row[1]]=0
#Doing normalization by dividing all values in j with 100 and making all the 
#elements combinedly from m and j fall under near number range to plot easily 
for x in j:
    j[x]=j[x]/100
#Iterating over the rows, checking if the year in row is present as a key in m
#If so, adding gdp_per_capita to the value of that particular key (which is year)
#if not, creating a key value pair with that year value of that particular row as key
for index, row in df.iterrows():
    if row[1] in m:
        m[row[1]]=m[row[1]]+row[4] 
    else:
        m[row[1]]=0

#Creating a column with zeros as values. 
#In reference with the future where we add world total suicides_no to the corresponding
#year
df['total']=0
df['total gdp_percap']=0
#Loop to add world total suicides_no and world gdp_percap to the corresponding years
#editing the total and total gdp_percap columns
for index,row in df.iterrows():    
    df.iloc[index,11]=m[row[1]]
    df.iloc[index,12]=j[row[1]]
#result=pd.DataFrame(df)
#result.to_csv("result.csv", index=False)
import matplotlib.pyplot as plt
#sorting m and j based on key values 
lists = sorted(m.items()) # sorted by key, return a list of tuples
lists1 = sorted(j.items()) # sorted by key, return a list of tuples

x, y = zip(*lists) # unpack a list of pairs into two tuples
a,b = zip(*lists1) # unpack a list of pairs into two tuples
lin,=plt.plot(x, y,'x') #ploting years on x axis and values of m on y
vin,=plt.plot(x,b,'g') #ploting years on x axis and values of normalized j on y
plt.legend([lin,vin], ['SUICIDES','WORLD GDP PER CAPITA in HUNDREDS']) #giving the plo legends
plt.title('WORLD GDP PER CAP vs WORLD SUICIDES BY YEAR')
plt.xlabel('year')
plt.ylabel('Value')
plt.show()


# In[ ]:



#3) METHOD 2 OF ANALYSIS
# Second analysis
#Initializing empty lists to hold year, suicide number and gender of corresponding country
#and for other purposes
yr=[]
cases=[]
gender=[]
pop=[]
hdi=[]
k=[]
p=[]
h=[]
t=[]
#Function to extract the year, suicide number and gender of required country
def country(name):
    global yr
    global cases
    global gender
    global hdi
    global pop
    global k
    global p
    global h
    global t
    yr.clear()
    cases.clear()
    gender.clear()
    pop.clear()
    hdi.clear()
    k.clear()
    p.clear()
    h.clear()
    t.clear()
    for index, row in df.iterrows():
        if name == row[0]:
            yr.append(row[1])
            cases.append(row[4])
            gender.append(row[2])
            pop.append(row[5])
            hdi.append(row[7])
            t.append(row[9])

c_name = input('Type the name of the country\n')  
country(c_name) 
#matplotlib is already imported as plt
import numpy as np
p= [10*(float(i)/max(pop)) for i in pop]
h= [10*(float(i)/max(hdi)) for i in hdi]
k = [10*(float(i)/max(cases)) for i in cases]
t = [10*(float(i)/max(t)) for i in t]                                   ####h = [g*10 for g in hdi]
                                                                        ####count = 0
                                                                        ####number = max(pop)
                                                                        ####while (number > 0):
                                                                        ####    number=number//10
                                                                        ####count+=1
                                                                        ####o=10**(count-2)
                                                                        ####p = [l/o for l in pop ]


# In[ ]:


line1, =plt.plot(yr,k,color='r',label='SUICIDES_NO',linestyle=':',linewidth=4)
line2, =plt.plot(yr,h,color='b',label='HDI',linewidth=7)
line3, =plt.plot(yr,p,color='g',label='POP in BILLION',linewidth=5)
line4, =plt.plot(yr,t,color='m',label='GDP',linewidth=9)

plt.legend([line1, line2,line3,line4], ['SUICIDES','HDI','POP','GDP']) 
plt.xlabel('years')
plt.ylabel('Values')
locs, labels = plt.xticks()
plt.xticks(np.arange(min(yr),max(yr), step=2))
plt.title('Report on'+' '+str(c_name))
plt.rcParams['font.size']=150
plt.rcParams['figure.figsize']=[200, 200]                                                                       
plt.show()                                                             ####locs, labels = plt.yticks()
                                                                       ####plt.yticks(np.arange(0,50,step=1))
                                                                       ####plt.rcParams['font.size']=15
                                                                       ####plt.rcParams['figure.figsize']=[200, 200]

